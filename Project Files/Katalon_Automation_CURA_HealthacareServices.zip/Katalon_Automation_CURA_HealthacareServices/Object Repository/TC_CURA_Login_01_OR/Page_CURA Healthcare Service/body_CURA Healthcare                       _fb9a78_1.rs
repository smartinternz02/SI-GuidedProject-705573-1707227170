<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_CURA Healthcare                       _fb9a78_1</name>
   <tag></tag>
   <elementGuidId>8571ed8f-e1db-4958-b671-31e13b0cebd6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>cc4e4127-85b6-49ff-aa00-997afa11c1c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;txt-username&quot;)</value>
      <webElementGuid>2d5c6270-1d32-4196-8982-42f71e07d814</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
      <webElementGuid>57831d01-fb21-4a7c-876f-0e594216361e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>d4f74caf-72db-4182-b197-df4c8e4b4d28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;txt-username&quot;)' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;txt-username&quot;)')]</value>
      <webElementGuid>88819d51-0b26-4a5d-b710-b62cf4a12855</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
