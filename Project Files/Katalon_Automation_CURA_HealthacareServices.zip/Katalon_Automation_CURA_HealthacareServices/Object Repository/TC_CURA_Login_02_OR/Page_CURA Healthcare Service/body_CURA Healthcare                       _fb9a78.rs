<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_CURA Healthcare                       _fb9a78</name>
   <tag></tag>
   <elementGuidId>9f7d0f81-4c2c-4748-a863-00a5cfdebc49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>2a1626ad-c8b5-485f-ba34-164219c0a61c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;txt-username&quot;)</value>
      <webElementGuid>db014803-d3ec-4402-9178-ef88c7162b25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
      <webElementGuid>e3010a5c-0e15-46e8-abb2-307b05e2a895</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>6be1a8c4-f8c7-46b2-b2a3-6c602f761b74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;txt-username&quot;)' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;txt-username&quot;)')]</value>
      <webElementGuid>e2a9efee-3fca-46da-8693-2254a0af33c9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
